#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i, n, s, sum=0;
    printf("Enter a number:");
    scanf("%d", &n);
    printf("\n");

    for(i=1; i<=n; i++)
    {
        s=4*i-3;
        sum=sum+s;
        printf("%d + ", s);
    }

    printf(".....nth\nSum of the total value : %d\n\n", sum);
    return 0;
}
